﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Cameo
{
    class QuietPlease
    {
        private Stream audio;

        public QuietPlease(Stream s)
        {

        }

        public void GetSoundLevel()
        {
           
        }


    }
}
