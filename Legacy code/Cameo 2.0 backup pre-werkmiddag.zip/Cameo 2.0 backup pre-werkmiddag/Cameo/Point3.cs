﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Cameo
{
    class Point3
    {
        public float X, Y, Z=0;

        public Point3(float x, float y, float z)
        {
            this.X = x;
            this.Y = y;
            this.Z = z;
        }
    }
}
